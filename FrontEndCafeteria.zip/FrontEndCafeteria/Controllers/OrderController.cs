﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using FrontEndCafeteria.Models;
using System.Diagnostics;
using System.Net.Http;
using Newtonsoft.Json;
using FrontEndCafeteria.Helpers;

namespace FrontEndCafeteria.Controllers
{
    public class OrderController : Controller
    {
        private static List<OrderModel> orders;

        //Normal Employee Actions:
        public async Task<IActionResult> IndexAsync()
        {
            orders = new List<OrderModel>();
            int userId = Int32.Parse(HttpContext.Session.GetString("UserID"));
            Dictionary<Int32, List<Int32>> mapUserToListOfProducts = MenuController.getUserToListOfProducts();
            Dictionary<Int32, Int32> mapProdToQuan = MenuController.getProdToQuan();
            List<Int32> idsOfProductsToBuy = new List<Int32>();
            List<Product> products = new List<Product>();
            idsOfProductsToBuy = mapUserToListOfProducts.GetValueOrDefault(userId);
            // For each product the user wants to buy, a new order is created.
            for (int i = 0; i < idsOfProductsToBuy.Count; i++)
            {
                int prodID = idsOfProductsToBuy.ElementAt(i);
                Api api = new Api();
                HttpClient client = api.Initial();
                // Getting the product record form the database.
                HttpResponseMessage getData = await client.GetAsync(string.Format("api/Products/" + prodID));
                if (getData.IsSuccessStatusCode)
                {
                    string result = getData.Content.ReadAsStringAsync().Result;
                    Product p = JsonConvert.DeserializeObject<Product>(result);
                    p.QuantityRequired = mapProdToQuan.GetValueOrDefault(prodID);
                    // Adding the product to the list
                    products.Add(p);
                    // Creating a new order.
                    OrderModel order = new OrderModel();
                    order.EmpID = userId;
                    order.productID = prodID;
                    order.productName = p.productName;
                    order.quantityRequired = mapProdToQuan.GetValueOrDefault(prodID);
                    order.totalprice = p.price * p.QuantityRequired;
                    orders.Add(order);
                }
            } 
            // Show all the orders made by the employee.
            return View(orders);
        }

        public async Task<IActionResult> Store() // Used to store the orders in the database.
        {
            int userId = Int32.Parse(HttpContext.Session.GetString("UserID"));
            Api api = new Api();
            HttpClient client = api.Initial();
            for (int i = 0; i < orders.Count; i++)
            {
                //POST
                //Store the order record in the database.
                var postTask = client.PostAsJsonAsync<OrderModel>("api/Order", orders.ElementAt(i));
                postTask.Wait();
                var result = postTask.Result;
                if (!result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Error", new { msg = "Order cannot be placed at the moment" });
                }
                //GET
                //Decrease the available quantity of the product to buy.
                int prodID = orders.ElementAt(i).productID;
                api = new Api();
                client = api.Initial();
                HttpResponseMessage getData = await client.GetAsync(string.Format("api/Products/" + prodID));
                if (getData.IsSuccessStatusCode)
                {
                    string r = getData.Content.ReadAsStringAsync().Result;
                    Product p = JsonConvert.DeserializeObject<Product>(r);
                    p.availableQuantity = p.availableQuantity - orders.ElementAt(i).quantityRequired;
                    var putTask = client.PutAsJsonAsync<Product>("api/Products/" + orders.ElementAt(i).productID, p);
                    putTask.Wait();
                    result = putTask.Result;
                    if (!result.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Error", new { msg = "Order cannot be placed at the moment" });
                    }
                }
            }
            // Finally, the list of orders, the list of products an employee wants to buy and the quantity required of each product are all cleared to be able to used after.
            orders.Clear();
            MenuController.clearUserToListOfProducts(userId);
            MenuController.clearProdToQuan();
            return View();
        }

        // Admin Actions:
        public async Task<IActionResult> Deliver() // used to show all the orders not yet delivered to the employee.
        {
            Api api = new Api();
            HttpClient client = api.Initial();
            HttpResponseMessage getData = await client.GetAsync("api/Order");
            List<OrderModel> orders = new List<OrderModel>();
            if (getData.IsSuccessStatusCode)
            {
                string result = getData.Content.ReadAsStringAsync().Result;
                orders = JsonConvert.DeserializeObject<List<OrderModel>>(result);
                // Sort the orders by date, the most earlier made first.
                orders.Sort(delegate (OrderModel x, OrderModel y) {
                    return x.dateandTime.CompareTo(y.dateandTime);
                });
                return View(orders);
            }
            return RedirectToAction("Error", new { msg = "Error Occured" });
        }

        public async Task<IActionResult> Complete(int orderID) // used to set an order as completed.
        {
            Api api = new Api();
            HttpClient client = api.Initial();
            HttpResponseMessage getData = await client.GetAsync(string.Format("api/Order/" + orderID));
            if (getData.IsSuccessStatusCode)
            {
                string r = getData.Content.ReadAsStringAsync().Result;
                OrderModel order = JsonConvert.DeserializeObject<OrderModel>(r);
                order.completed = 1;
                // Put request.
                var putTask = client.PutAsJsonAsync<OrderModel>("api/Order/" + orderID, order);
                putTask.Wait();
                var result = putTask.Result;
                if (!result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Error", new { msg = "Order cannot be placed at the moment" });
                }
            }
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error(string msg)
        {
            return View(new ErrorViewModel { errorMessage = msg, RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
