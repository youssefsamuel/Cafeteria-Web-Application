﻿using FrontEndCafeteria.Helpers;
using FrontEndCafeteria.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace FrontEndCafeteria.Controllers
{
    public class MenuController : Controller
    {
        private static Dictionary<Int32, List<Int32>> mapUserToListOfProducts; // used to get the list of products to buy by each employee (key = employee id, value = list of products he wants to buy.)
        private static Dictionary<Int32, Int32> mapProdToQuan; // used to get the quantity required to buy for each product by the current employee logged in.

        public static Dictionary<Int32, List<Int32>> getUserToListOfProducts()
        {
            return mapUserToListOfProducts;
        }
        public static Dictionary<Int32, Int32> getProdToQuan()
        {
            return mapProdToQuan;
        }
        public static void clearUserToListOfProducts(int id)
        {
            mapUserToListOfProducts.GetValueOrDefault(id).Clear();
        }
        public static void clearProdToQuan()
        {
            mapProdToQuan = null;
        }

        //Normal Employee Actions:
        public async Task<IActionResult> Index(Employee emp)
        {
            int id = Int32.Parse(HttpContext.Session.GetString("UserID")); // get the id of the current employee.
            Api api = new Api();
            HttpClient client = api.Initial();
            HttpResponseMessage getData = await client.GetAsync("api/Products"); //getting all the products in the database to show them in menu.
            List<Product> products = new List<Product>();
            if (getData.IsSuccessStatusCode)
            {
                string result = getData.Content.ReadAsStringAsync().Result;
                products = JsonConvert.DeserializeObject<List<Product>>(result);
                ViewBag.User = emp;
                return View(products); // Show the menu of all the products.
            }
            return Error();
        }

        public ActionResult AddCart(int prodID, int userid) // used to add a product to the cart of the current employee
        {
            if (mapUserToListOfProducts == null)
            {
                mapUserToListOfProducts = new Dictionary<int, List<int>>();
            }
            List<Int32> list = new List<Int32>();
            if (mapUserToListOfProducts.TryGetValue(userid, out list))
            {
                mapUserToListOfProducts.GetValueOrDefault(userid).Add(prodID);
            }
            else
            {
                list = new List<Int32>();
                list.Add(prodID);
                mapUserToListOfProducts.Add(userid, list);
            }
            return View();
        }
        public ActionResult DeleteCart(int prodID, int userid) // used to remove a product from the cart of the current employee.
        {
            List<Int32> list = new List<Int32>();
            if (mapUserToListOfProducts.TryGetValue(userid, out list))
            {
                mapUserToListOfProducts.GetValueOrDefault(userid).Remove(prodID);
                if (mapUserToListOfProducts.GetValueOrDefault(userid).Count == 0)
                {
                    mapUserToListOfProducts.Remove(userid);
                }
            }
            return View();
        }

        public void Checkout(List<Int32> quantities, List<Int32> products) // used to store the quantity required of each product to buy.
        {
            mapProdToQuan = new Dictionary<Int32, Int32>();
            for (int i = 0; i < quantities.Count; i++)
            {
                mapProdToQuan.Add(products[i], quantities[i]);
            }
            // After this function is completed the ajax call in the view move to the Index action in Order Controller.
        }

        //Admin Actions:
        public IActionResult AddNew() // Used to add a new product to the database by the admin.
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddNew(Product product) 
        {
            Api api = new Api();
            HttpClient client = api.Initial();
            //HTTP POST to store the product in the table.
            var postTask = client.PostAsJsonAsync<Product>("api/Products", product);
            postTask.Wait();
            var result = postTask.Result;
            if (result.IsSuccessStatusCode)
            {
                return RedirectToAction("Admin", "Home");
            }
            return RedirectToAction("Error", new { msg = "Email already exists" });
        }

        public async Task<IActionResult> Increase() // used to show all the available products to the admin, so he can change the quantity of any product.
        {
            Api api = new Api();
            HttpClient client = api.Initial();
            HttpResponseMessage getData = await client.GetAsync("api/Products");
            List<Product> products = new List<Product>();
            if (getData.IsSuccessStatusCode)
            {
                string result = getData.Content.ReadAsStringAsync().Result;
                products = JsonConvert.DeserializeObject<List<Product>>(result);
                return View(products);
            }
            return View();
        }
        public async Task<IActionResult> SaveQuantity(int prodID, int newQuantity) // used by admin to change the available quantity of a specific product
        {
            Api api = new Api();
            HttpClient client = api.Initial();
            HttpResponseMessage getData = await client.GetAsync(string.Format("api/Products/" + prodID));
            if (getData.IsSuccessStatusCode)
            {
                string r = getData.Content.ReadAsStringAsync().Result;
                Product p = JsonConvert.DeserializeObject<Product>(r);
                p.availableQuantity = newQuantity;
                var putTask = client.PutAsJsonAsync<Product>("api/Products/" + prodID, p);
                putTask.Wait();
                var result = putTask.Result;
                if (!result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Error", new { msg = "Error Occured" });
                }
            }
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
